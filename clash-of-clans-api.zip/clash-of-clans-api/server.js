const express = require('express');
const axios = require('axios');
const cors = require('cors'); // Importamos cors
const fs = require('fs'); // Import fs module for file operations
const app = express();
const port = 3000;

// API de Clash of Clans - tu clave
const apiKey = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6IjIzMDI2Yjc1LWNjZWMtNDA4OC05YTE5LWJlZTZiNmE2OGY0YyIsImlhdCI6MTc0NTM0MDE1Niwic3ViIjoiZGV2ZWxvcGVyLzkyZTU5NzNhLTI5ZjMtYmJiNi0yZGRiLTIxYWQ1ZjBkNzA4YiIsInNjb3BlcyI6WyJjbGFzaCJdLCJsaW1pdHMiOlt7InRpZXIiOiJkZXZlbG9wZXIvc2lsdmVyIiwidHlwZSI6InRocm90dGxpbmcifSx7ImNpZHJzIjpbIjM0LjU3LjExNi4xNjYiLCIzNy4xNS44Mi4xNDYiXSwidHlwZSI6ImNsaWVudCJ9XX0.jtubEuv3Gc16ob61owGcjdASlqdNFBqkmeinAI4Kta3WPjgmr0FWNdu96MIj5ZL_5Qxi-VXaV82FG2C-CstmnQ';
const baseUrl = 'https://api.clashofclans.com/v1';

// Usamos cors para habilitar solicitudes entre orígenes
app.use(cors()); 

// Obtener información sobre el clan
app.get('/clans/:clanTag', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag); // Encode the clanTag
    const response = await axios.get(`${baseUrl}/clans/${encodedClanTag}`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener información del clan' });
  }
});

// Obtener la información sobre el grupo de guerra del clan
app.get('/clans/:clanTag/currentwar/leaguegroup', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag); // Encode the clanTag
    const response = await axios.get(`${baseUrl}/clans/${encodedClanTag}/currentwar/leaguegroup`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error });
    
  }
});

// Obtener información sobre la guerra actual del clan
app.get('/clans/:clanTag/currentwar', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag); // Encode the clanTag
    const response = await axios.get(`${baseUrl}/clans/${encodedClanTag}/currentwar`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener la guerra actual del clan' });
  }
});

// Obtener el registro de guerra del clan
app.get('/clans/:clanTag/warlog', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag); // Encode the clanTag
    const response = await axios.get(`${baseUrl}/clans/${encodedClanTag}/warlog`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener el registro de guerra del clan' });
  }
});

// Buscar clanes
app.get('/clans', async (req, res) => {
  try {
    const response = await axios.get(`${baseUrl}/clans`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
      params: req.query // para permitir parámetros de búsqueda como "name", "location", etc.
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al buscar clanes' });
  }
});
app.get('/clans/:clanTag/members/details/save', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag);
    const membersResponse = await axios.get(`${baseUrl}/clans/${encodedClanTag}/members`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });

    const members = membersResponse.data.items;

    // Hacer una petición por cada jugador para obtener su información detallada
    const detailedMembers = await Promise.all(members.map(async (member) => {
      try {
        const encodedPlayerTag = encodeURIComponent(member.tag);
        const playerResponse = await axios.get(`${baseUrl}/players/${encodedPlayerTag}`, {
          headers: { 'Authorization': `Bearer ${apiKey}` },
        });
        return playerResponse.data; // Retorna la información completa del jugador
      } catch (error) {
        console.error(`Error obteniendo info de ${member.tag}:`, error.message);
        return { error: `No se pudo obtener información para el jugador ${member.tag}` };
      }
    }));

    // Obtener la fecha y hora actual y formatearla
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-'); // Formato YYYY-MM-DDTHH-MM-SS

    // Crear la carpeta "saves" si no existe
    const savesDir = './saves';
    if (!fs.existsSync(savesDir)) {
      fs.mkdirSync(savesDir);
    }

    // Guardar el resultado en un archivo .json dentro de la carpeta "saves"
    const filePath = `${savesDir}/clan_${req.params.clanTag}_members_details_${timestamp}.json`;
    fs.writeFileSync(filePath, JSON.stringify({ detailedMembers }, null, 2), 'utf-8');

    res.json({ message: 'Datos guardados exitosamente', filePath });
  } catch (error) {
    console.error('Error al guardar los miembros del clan con detalles:', error.message);
    res.status(500).json({ error: 'Error al guardar los miembros del clan con detalles' });
  }
});
// Obtener los miembros de un clan con información detallada de cada jugador
app.get('/clans/:clanTag/members/details', async (req, res) => {
    try {
      const encodedClanTag = encodeURIComponent(req.params.clanTag);
      const membersResponse = await axios.get(`${baseUrl}/clans/${encodedClanTag}/members`, {
        headers: { 'Authorization': `Bearer ${apiKey}` },
      });
  
      const members = membersResponse.data.items;
  
      // Hacer una petición por cada jugador para obtener su información detallada
      const detailedMembers = await Promise.all(members.map(async (member) => {
        try {
          const encodedPlayerTag = encodeURIComponent(member.tag);
          const playerResponse = await axios.get(`${baseUrl}/players/${encodedPlayerTag}`, {
            headers: { 'Authorization': `Bearer ${apiKey}` },
          });
          return playerResponse.data; // Retorna la información completa del jugador
        } catch (error) {
          console.error(`Error obteniendo info de ${member.tag}:`, error.message);
          return { error: `No se pudo obtener información para el jugador ${member.tag}` };
        }
      }));
  
      res.json({ detailedMembers }); // Retorna la lista con información detallada de cada jugador
    } catch (error) {
      console.error('Error al obtener los miembros del clan:', error.message);
      res.status(500).json({ error: 'Error al obtener los miembros del clan con detalles' });
    }
  });
  
// Obtener información de un jugador
app.get('/players/:playerTag', async (req, res) => {
  try {
    const encodedPlayerTag = encodeURIComponent(req.params.playerTag); // Encode the playerTag
    const response = await axios.get(`${baseUrl}/players/${encodedPlayerTag}`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener la información del jugador' });
  }
});


// Verificar el token del jugador
app.post('/players/:playerTag/verifytoken', async (req, res) => {
  try {
    const encodedPlayerTag = encodeURIComponent(req.params.playerTag); // Encode the playerTag
    const response = await axios.post(`${baseUrl}/players/${encodedPlayerTag}/verifytoken`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al verificar el token del jugador' });
  }
});

// Obtener la temporada de incursiones capitales del clan
app.get('/clans/:clanTag/capitalraidseasons', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag); // Encode the clanTag
    const response = await axios.get(`${baseUrl}/clans/${encodedClanTag}/capitalraidseasons`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener las temporadas de incursiones capitales' });
  }
});

// Obtener los miembros de un clan
app.get('/clans/:clanTag/members', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag); // Encode the clanTag
    const response = await axios.get(`${baseUrl}/clans/${encodedClanTag}/members`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener los miembros del clan' });
  }
});

// Obtener información sobre una guerra específica en la liga de guerra del clan
app.get('/clanwarleagues/wars/:warTag', async (req, res) => {
  try {
    const encodedWarTag = encodeURIComponent(req.params.warTag); // Encode the clanTag
    const response = await axios.get(`${baseUrl}/clanwarleagues/wars/${encodedWarTag}`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener la guerra específica' });
  }
});

// Route to get all saves
app.get('/saves', async (req, res) => {
  try {
    const savesDir = './saves';

    // Verificar si la carpeta "saves" existe
    if (!fs.existsSync(savesDir)) {
      return res.status(404).json({ error: 'No se encontró la carpeta de saves' });
    }

    // Leer los archivos dentro de la carpeta "saves"
    const files = fs.readdirSync(savesDir);

    // Leer y parsear el contenido de cada archivo
    const saves = files.map((file) => {
      const filePath = `${savesDir}/${file}`;
      const content = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      return { fileName: file, content };
    });

    res.json(saves);
  } catch (error) {
    console.error('Error al obtener los saves:', error.message);
    res.status(500).json({ error: 'Error al obtener los saves' });
  }
});

// Route to get saves filtered by clanTag
app.get('/saves/:clanTag', async (req, res) => {
  try {
    const savesDir = './saves';

    // Verificar si la carpeta "saves" existe
    if (!fs.existsSync(savesDir)) {
      return res.status(404).json({ error: 'No se encontró la carpeta de saves' });
    }

    // Leer los archivos dentro de la carpeta "saves"
    const files = fs.readdirSync(savesDir);

    // Filtrar los archivos por clanTag
    const { clanTag } = req.params;
    const filteredFiles = files.filter((file) => file.includes(`clan_${clanTag}_`));

    // Leer y parsear el contenido de cada archivo filtrado
    const saves = filteredFiles.map((file) => {
      const filePath = `${savesDir}/${file}`;
      const content = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      return { fileName: file, content };
    });

    res.json(saves);
  } catch (error) {
    console.error('Error al obtener los saves:', error.message);
    res.status(500).json({ error: 'Error al obtener los saves' });
  }
});

app.get('/clans/:clanTag/currentwar/leaguegroup/details', async (req, res) => {
  try {
    const encodedClanTag = encodeURIComponent(req.params.clanTag); // Encode the clanTag
    const leagueGroupResponse = await axios.get(`${baseUrl}/clans/${encodedClanTag}/currentwar/leaguegroup`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    });

    const leagueGroupData = leagueGroupResponse.data;
    console.log(leagueGroupData, 'leagueGroupData'); // Log the leagueGroupData for debugging
    
    const rounds = leagueGroupData.rounds || [];
    const matchingWars = [];

    // Iterar sobre los rounds y sus warTags
    for (const round of rounds) {
      for (const warTag of round.warTags) {
        if (warTag === '#0') continue; // Ignorar warTags vacíos

        try {
          const encodedWarTag = encodeURIComponent(warTag);
          const warResponse = await axios.get(`${baseUrl}/clanwarleagues/wars/${encodedWarTag}`, {
            headers: { 'Authorization': `Bearer ${apiKey}` },
          });

          const warData = warResponse.data;

          // Verificar si el clanTag coincide con alguno de los clanes en la guerra
          const isMatchingWar = warData.clan?.tag === req.params.clanTag || warData.opponent?.tag === req.params.clanTag;

          if (isMatchingWar) {
            matchingWars.push(warData);
          }
        } catch (error) {
          console.error(`Error al obtener información de la guerra con warTag ${warTag}:`, error.message);
        }
      }
    }

    res.json({ message: 'Procesamiento completado', matchingWars });
  } catch (error) {
    console.error('Error al procesar el grupo de guerra del clan:', error.message);
    res.status(500).json({ error: 'Error al procesar el grupo de guerra del clan' });
  }
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor de Clash of Clans API escuchando en el puerto ${port}`);
});
